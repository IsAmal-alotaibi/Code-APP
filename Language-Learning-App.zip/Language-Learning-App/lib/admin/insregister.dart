import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

class RegisterInstructor extends StatefulWidget {
  const RegisterInstructor({super.key});

  @override
  State<RegisterInstructor> createState() => _RegisterInstructorState();
}

class _RegisterInstructorState extends State<RegisterInstructor> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}